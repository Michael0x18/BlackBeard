package server.net;

public interface ExecutionListener {
	
	public void execute(ExecutionEvent e);

}
