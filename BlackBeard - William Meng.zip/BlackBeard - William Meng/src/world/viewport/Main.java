package world.viewport;

public class Main {
	
	public static void main(String[] args) {
		JoglPane._driver_start(args);
	}

}
