package world.constants.declaration;

public interface ViewConstants {

	public static double ABSOLUTE_RENDER_RANGE = 15;

}
