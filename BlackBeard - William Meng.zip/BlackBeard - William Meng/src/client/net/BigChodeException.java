package client.net;

public class BigChodeException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1430607723524757249L;
	
	

}
