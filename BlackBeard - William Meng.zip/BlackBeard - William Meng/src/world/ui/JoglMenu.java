package world.ui;

import javax.swing.JFrame;
import javax.swing.JMenuBar;

public class JoglMenu {
	
	public static JMenuBar applyMenu(JFrame f) {
		JMenuBar jmb = new JMenuBar();
		f.setJMenuBar(jmb);
		return jmb;
	}

}
