package client.net;

import javax.swing.JFrame;

public class Loader extends JFrame{

	public Loader() {
		super();
		this.setUndecorated(true);
		this.setBounds(0,0,400,200);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

}
