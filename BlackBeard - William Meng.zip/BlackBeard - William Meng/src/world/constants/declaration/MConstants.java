package world.constants.declaration;

public interface MConstants {
	public static final double TWO_PI = 2*Math.PI;
	public static final double PI = Math.PI;
	public static final double HALF_PI = Math.PI/2;
	public static final double TAU = TWO_PI;

}
